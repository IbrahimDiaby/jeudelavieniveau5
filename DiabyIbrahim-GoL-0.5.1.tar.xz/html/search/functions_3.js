var searchData=
[
  ['efface_5fgrille',['efface_grille',['../io_8h.html#ab36a6f8957cd3e682119007836ce6ad5',1,'efface_grille(grille g):&#160;io.c'],['../io_8c.html#ab36a6f8957cd3e682119007836ce6ad5',1,'efface_grille(grille g):&#160;io.c']]],
  ['est_5fnonviable',['est_nonViable',['../grille_8h.html#a4a09035c33865ee6ff8db67aff3d3af2',1,'grille.h']]],
  ['est_5fvivante',['est_vivante',['../grille_8h.html#aac3db82b0f857dc49ccd51628cbc231b',1,'grille.h']]],
  ['evolue',['evolue',['../jeu_8h.html#aa97c0fafeb752bb66a038e73b7b5a36d',1,'evolue(grille *g, grille *gc, cellule *C, int(*compte_voisins_vivants)(int, int, grille), int vieillissement):&#160;jeu.c'],['../jeu_8c.html#aa97c0fafeb752bb66a038e73b7b5a36d',1,'evolue(grille *g, grille *gc, cellule *C, int(*compte_voisins_vivants)(int, int, grille), int vieillissement):&#160;jeu.c']]]
];
