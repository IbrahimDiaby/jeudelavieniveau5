var searchData=
[
  ['sizex',['SIZEX',['../main_8c.html#a3d6d12a6ee0d7d77f3f180ed1b2a1e22',1,'main.c']]],
  ['sizey',['SIZEY',['../main_8c.html#a7e1991fcd344daa8c9e423cfd3481a8c',1,'main.c']]]
];
